import graphviz

"""
Pseudodag

dag directed acyclic graph

"""

fname = input("\tPlease Enter your event log specification filename [Note, for each line, you may declare what each node linguistically means - also, filename.txt is the correct format]: ")
fmode = input("\nPlease enter the file mode required [w = write, r = read]: ")
p = open(fname,fmode)

i = 0
o = input("\nPlease Enter the number of nodes to be included in the Directed Acyclic Graph [DAG]: ")
print("You entered: " + o)

rn = input("\nEnter the number of entries to be made in the specification text file: ")
rin = int(rn)
io = 0


for io in range(0,rin):
    if(fmode == 'w'):
        i = i + 1
        z = str(i)
        take = input("--> ")
        p.write(take)
        p.write("\n")


switch = input("\nDo you want to formulate the DAG file [1 = yes , 0 = no]? ")

if(switch == '0'):
    exit()
if(switch == '1'):
    switch_a = int(switch)

gv_fname = input("\nPlease Enter the filename of the Digraph to be formed [filename.gv for example]: ")


f = graphviz.Digraph('finit_state_machine', filename = gv_fname)

x_val = input("\nPlease input the x_value of the Digraph canvas [9x9 is a decent size for 13 nodes and 21 vertices]: ")
y_val = input("\nPlease input the y_value of the Digraph canvas: ")

f.attr(rankdir='LR', size= x_val + ',' + y_val)

f.attr('node', shape = 'circle')

edge_ll = input("\nPlease create a common label for each edge [Each label will be made unique by their ID number]: ")

edge_ID = 1
e_ID = str(edge_ID)

"""
on = input("\nPlease Enter the number of edges to be included in the Directed Acyclic Graph [DAG] or enter WHILE to use the while loop instead: ")
if(on != 'WHILE' and ):
    on_in = int(on)
ip = 0
"""

print("Begin: reading from left to right. Starting with the Left_node label toward the Right_node label until complete ...")

ip = 0
while(ip != 1):
    if (switch_a == 1):
        l_node = input("\nLeft_node label: ")
        r_node = input("\nRight_node label: ")

        f.edge(l_node, r_node, label = edge_ll + e_ID)
        edge_ID = edge_ID + 1
        e_ID = str(edge_ID)

        q = input("\nContinue [y = yes , n = no]? ")
        if(q == 'n'):
            ip = 1
        else:
            ip = 0

view_f = input("\nDo you want to save and view the DAG file [1 = yes , 0 = no]? ")

if(view_f == '1'):
    f.view()

p.close()



